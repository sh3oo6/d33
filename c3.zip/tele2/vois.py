

client = TelegramClient("session", api_id, api_hash,connection=connection.ConnectionTcpMTProxyRandomizedIntermediate,proxy=('2.56.212.228', 6968, '511ea7f92d97a5fe5ae283f9cb3b6cdb'))
client.start()






while True:
    o = open(f"on_off{numb_s}.txt", 'r').read()
    if o == "False":
        break
    del o
    await asyncio.sleep(1)
    for dialog in await client.get_dialogs():
        if dialog.is_user:
            await client.delete_dialog(dialog)
    await asyncio.sleep(1)
    botT.send_message(user,f"اسم الحساب: {name}\nرقم الحساب: {numb_s}\nبدء التجميع")
    try:
        o = open(f"on_off{numb_s}.txt", 'r').read()
        if o == "False":
            break
        del o
        try:
            await client.send_message(userbot ,'/start')
        except:
            await client(functions.contacts.UnblockRequest(idbot))
            await client.send_message(userbot ,'/start')
        await asyncio.sleep(4)
        while True:
              messages = await client.get_messages(userbot , limit=1)
              message = messages[0]
              message = (message.message)
              if "أهلاً بك" in message:
                  break
              elif "@" in message:
                      text = message.find("@") + len("@")
                      fi = message.find("\n", text)
                      nk = str(message[text:fi])
                      link = f"https://t.me/{nk}"
                      await client(JoinChannelRequest(link))
                      botT.send_message(user,f"اسم الحساب: {name}\nرقم الحساب: {numb_s}\nتم الاشتراك في قناة الاجباري \n : {link}")
                      await client.send_message(userbot ,'/start')
                      await asyncio.sleep(4)
              elif "http" in message:
                  m = re.findall(pattern, message)
                  for link in m:
                      try:
                          await client(JoinChannelRequest(link))
                      except:
                          try:
                              urlg = link.split('+')[1]
                              await client(ImportChatInviteRequest(urlg))
                          except:
                              urlg = link.split('/')[-1]
                              await client(ImportChatInviteRequest(urlg))
                      botT.send_message(user,f"اسم الحساب: {name}\nرقم الحساب: {numb_s}\nتم الاشتراك في قناة الاجباري \n : {link}")
                      await client.send_message(userbot ,'/start')
                      await asyncio.sleep(4)
              elif message == "/start":
                  await client.send_message(userbot ,'/start')
                  await asyncio.sleep(4)