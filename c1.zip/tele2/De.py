from telethon.sync import *
from time import sleep
import requests

userbot='@zmmbot'
Dex = '6140911166'
Des = '6243358528:AAFaAucqXoIHltgcKhKwlpkv6ZqcfVuhhi8'
V=58
def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')
def dele():
    def dle(cc):
        try:
            client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
            client.start()
            dialogs = client.get_dialogs()

            for dialog in dialogs:
                entity = dialog.entity

                try:
                    xu = entity.username
                    xn = entity.title
                except:
                    pass

                try:
                    if xu == 'dexsuper':
                        pass
                    elif xu == 'DamKombot':
                        pass
                    elif xu == 'dex33bb':
                        pass
                    elif dialog.is_user:
                        pass
                    else:
                        client.delete_dialog(entity)
                except:
                    pass
        except Exception:
            pass
    g = 1
    for ffguf in range(1000):
        F = ("dex" + str(g))
        dle(F)

        if int(g) == int(V):
            sd('cliened')
            break
        else:
            g = g + 1
dele()


def bot2(cc):
    userbot = '@ihyberbot'
    try:
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.start()
        sleep(1)
        client.send_message(userbot, '/start 5229914714')
        sleep(3)
        for x in range(22):
            l1 = client.get_messages(userbot, limit=1)
            l2 = l1[0].message
            if l2 == "/start":
                client.send_message(userbot, '/start')
                sleep(1)
                continue
            if l2 == "البوت تحت الصيانة حالياً 🛠️":
                sleep(7000)
                client.send_message(userbot, '/start')
                sleep(1)
                continue
            if "@" in l2:
                text = l2.find("@") + len("@")
                fi = l2.find("\n", text)
                nk = str(l2[text:fi])
                client(JoinChannelRequest("https://t.me/" + nk))
                client.send_message(userbot, '/start')
                sleep(1)
            else:
                break
        mscsag1 = client.get_messages(userbot, limit=1)
        mscsag1[0].click(0)
        sleep(3)

        mscsag2 = client.get_messages(userbot, limit=1)
        mscsag2[0].click(0)
        sleep(3)
        for ee in range(25):
            try:
                mscsag35 = client.get_messages(userbot, limit=1)
                l2 = mscsag35[0].message
                if 'لا يوجد قنوات حالياً 🤍' in l2:
                    break
                text = l2.find("@") + len("@")
                fi = l2.find("\n", text)
                nk = str(l2[text:fi])
                print(nk)
                client(JoinChannelRequest("https://t.me/" + nk))
                mscsag36 = client.get_messages(userbot, limit=1)
                mscsag36[0].click(1)
                sleep(3)
            except:
                mscsag36 = client.get_messages(userbot, limit=1)
                mscsag36[0].click(2)

        mscsag34 = client.get_messages(userbot, limit=1)
        mscsag34[0].click(0)
        sleep(3)

        l14 = client.get_messages(userbot, limit=1)
        l24 = l14[0].message
        regex1 = r'[01234567890]\w+'
        she = re.findall(regex1, l24)
        print(she[0])



    except:
        pass
