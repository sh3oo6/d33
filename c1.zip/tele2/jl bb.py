from telethon.sync import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest

import re
from telethon import functions
import requests
from time import sleep

api_id = 2192036
api_hash = '5938772476:AAHaSgf6WdTHQd1RqUifucJaaf11CQ0tkAg'
def dex1():
    v = input("  How many Accounts to add?  ")
    c = input("  How many Accounts you added?  ")
    G = (int(c) + 1)
    b = int(v) + int(c)
    for ffguf in range(int(v)):
        cc = ("dex" + str(G))
        api_id = 2192036
        api_hash = '3b86a67fc4e14bd9dcfc2f593e75c841'
        client = TelegramClient(cc, api_id, api_hash)
        client.start()
        print(cc + client.get_me().first_name)
        #client.send_message('@eeobot', '/start 6140911166')
        client(JoinChannelRequest(1783766858))
        #client(JoinChannelRequest("https://t.me/FFF22"))
        #(JoinChannelRequest("https://t.me/Fvvvv"))
        #client.session.save()
        client.disconnect()
        sleep(1)
        if G == b:
            print("  Completed")
            break
        G += 1
dex1()
