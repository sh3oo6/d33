from telethon.sync import TelegramClient , errors

phone_number = '9647855200214'
try:
	iqthon = TelegramClient('ledA', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
	iqthon.connect()

	if not iqthon.is_user_authorized():
		request = iqthon.send_code_request(phone_number)
		code = input('code')
		response_verification_code =code
		try:
			login = iqthon.sign_in(phone_number, code=int(code))
		except errors.SessionPasswordNeededError:
			password = input('pass')
			iqthon.sign_in(phone_number, password=password)
			iqthon.disconnect()
except:pass