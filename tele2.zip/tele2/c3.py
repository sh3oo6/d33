from telethon.sync import *
from telethon.tl.functions.channels import JoinChannelRequest
import re
import requests
from time import sleep
from telethon.tl.functions.messages import GetHistoryRequest, ImportChatInviteRequest
import asyncio

#Dex = '5229914714'
#Des = '5938772476:AAHaSgf6WdTHQd1RqUifucJaaf11CQ0tkAg'
Dex = '6140911166'
#Des = '6312593326:AAHxQ-9-buwS6q70dCOvhKvkJaBWkzKZcZg'
Des = '6165670532:AAF_t-JAz0r2PJEPplthoBSjyxt6DB9K8j0'
def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')

userbot='@DamKombot'
userbot2='@eeobot'
def dex2():
    V=20

    def jd3():
        g = 1
        for dl in range(V):
            cc = ("dex" + str(g))
            try:
                client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
                client.start()
                sleep(0.5)
                sleep(1)
                client.send_message(userbot, '/start')
                sleep(3)
                for x in range(22):
                    l1 = client.get_messages(userbot, limit=1)
                    l2=l1[0].message
                    if l2 == "/start":
                        client.send_message(userbot, '/start')
                        sleep(1)
                        continue
                    if l2 == "البوت تحت الصيانة حالياً 🛠️":
                        sleep(7000)
                        client.send_message(userbot, '/start')
                        sleep(1)
                        continue
                    if "@" in l2:
                        text = l2.find("@") + len("@")
                        fi = l2.find("\n", text)
                        nk = str(l2[text:fi])
                        client(JoinChannelRequest("https://t.me/" + nk))
                        client.send_message(userbot, '/start')
                        sleep(1)
                    else:
                        break
                sleep(1)
                mscsag33 = client.get_messages(userbot, limit=1)
                mscsag33[0].click(1)
                sleep(3)
                mscsag34 = client.get_messages(userbot, limit=1)
                mscsag34[0].click(0)
                sleep(3)
                i=0
                for ee in range(25):
                    try:
                        mscsag35 = client.get_messages(userbot, limit=1)
                        l2 = mscsag35[0].message
                        if 'لا يوجد قنوات حالياً 🤍' in l2:
                            #sd(cc+' '+str(i))
                            break
                        #text = l2.find("@") + len("@")
                        nk = str(l2[15:])
                        client(JoinChannelRequest(nk))
                        mscsag36 = client.get_messages(userbot, limit=1)
                        mscsag36[0].click(0)
                        sleep(3)
                        i+=1
                    except:
                        mscsag36 = client.get_messages(userbot, limit=1)
                        mscsag36[0].click(0)
                sleep(3)
                mscsag38 = client.get_messages(userbot, limit=1)
                mscsag38[0].click(0)
                sleep(3)
                mssag11 = client.get_messages(userbot, limit=1)
                x = mssag11[0].click(2)
                mscsag40 = client.get_messages(userbot, limit=1)
                m40 = mscsag40[0].message
                if '🗃️ الحساب' in m40:
                    sleep(3)
                    mscsag37 = client.get_messages(userbot, limit=1)
                    mscsag37[0].click(2)
                    sleep(3)
                    l14 = client.get_messages(userbot, limit=1)
                    l24 = l14[0].message
                    regex1 = r'[1234567890]\w+'
                    she = re.findall(regex1, l24)
                    sleep(3)
                    mscsag5 = client.get_messages(userbot, limit=1)
                    mscsag5[0].click(4)
                    sleep(1.5)
                    client.send_message(userbot, Dex)
                    sleep(2)
                    client.send_message(userbot, she[0])
                    bot2(cc, client , i)
                    client.disconnect()
                else:
                    bot2(cc, client , i)
                    client.disconnect()
            except Exception:
                print('jj')
                pass
            g = g + 1


    def bot2(cc,client,i):
        try:
            sleep(320)
            userbot = '@eeobot'
            client.send_message(userbot, '/start')
            sleep(2.7)
            chen = client.get_entity(userbot)
            for ghh in range(10):
                l1 = client.get_messages(userbot, limit=1)
                l2 = l1[0].message
                if l2 == "/start":
                    client.send_message(userbot, '/start')
                    sleep(0.8)
                if 'عليك' in l2:
                    regex = r'[-+qwertyuiopasdfghjklzxcvbnmPOIUYTREWQASDFGHJKLZXCVBNM1234567890]\w+'
                    sht = re.findall(regex, l2)
                    if sht[1] == 'start':
                        try:
                            cx = "https://t.me" + sht[0]
                            client(JoinChannelRequest(cx))
                        except Exception:
                            cx = "https://t.me/" + sht[0]
                            client(JoinChannelRequest(cx))
                    elif sht[3] == 'start':
                        try:
                            c = "https://t.me" + sht[2]
                            client(JoinChannelRequest(c))
                        except Exception:
                            c = "https://t.me/" + sht[2]
                            client(JoinChannelRequest(c))
                    elif sht[4] == 'start':

                        try:
                            t = "https://t.me" + sht[2] + sht[3]
                            client(JoinChannelRequest(t))
                        except Exception:
                            try:
                                t = "https://t.me/" + sht[2] + sht[3]
                                client(JoinChannelRequest(t))
                            except Exception:
                                t = "https://t.me/" + sht[2] + '/' + sht[3]
                                client(JoinChannelRequest(t))
                    else:
                        try:
                            r = "https://t.me" + sht[2] + sht[3] + sht[4]
                            client(JoinChannelRequest(r))
                        except Exception:
                            try:
                                r = "https://t.me/" + sht[2] + sht[3] + sht[4]
                                client(JoinChannelRequest(r))
                            except Exception:
                                r = "https://t.me/" + sht[2] + '/' + sht[3] + sht[4]
                                client(JoinChannelRequest(r))
                                #########+___+########
                    client.send_message(userbot, '/start')
                    sleep(1.1)
                else:
                    break
            mssag11 = client.get_messages(userbot, limit=1)
            xe1 = mssag11[0].click(0).message
            #client.send_message(userbot, '/start')
            #mscsag12 = client.get_messages(userbot, limit=1)
            mssag11[0].click(2)
            mssag13 = client.get_messages(userbot, limit=1)
            mssag13[0].click(0)
            bn = 1
            for ffguf in range(100):
                lx = client(
                    GetHistoryRequest(peer=chen, limit=1, offset_date=None, offset_id=0, max_id=0,
                                      min_id=0,
                                      add_offset=0, hash=0))
                jx = lx.messages[0]
                vvf=jx.message
                if ('تم اضافة') in vvf or ('لا يوجد قنوات في الوقت الحالي') in vvf:
                    mssag16 = client.get_messages(userbot, limit=1)
                    mssag16[0].click(1)
                    sleep(1)
                    mssag17 = client.get_messages(userbot, limit=1)
                    xs = mssag17[0].click(0).message
                    io = (int(xs) - int(xe1))
                    sd(f'👾 start {cc} not have {xe1}({io}) -- [{i}]')
                    client.disconnect()
                    break
                if ('• تم خصم 16 من نقاطك ⭕️') in vvf :
                    client.send_message(userbot, '/start')
                    sleep(3)
                    mscsag12 = client.get_messages(userbot, limit=1)
                    mscsag12[0].click(2)
                    mssag13 = client.get_messages(userbot, limit=1)
                    mssag13[0].click(0)
                    continue

                try:
                    url = jx.reply_markup.rows[0].buttons[0].url
                    client(JoinChannelRequest(url))
                    mssag15x = client.get_messages(userbot, limit=1)
                    mssag15x[0].click(1)
                except Exception:
                    mssag14 = client.get_messages(userbot, limit=1)
                    mssag14[0].click(1)
                    if bn == 3:
                        mssag16 = client.get_messages(userbot, limit=1)
                        mssag16[0].click(4)
                        sleep(1)
                        mssag17 = client.get_messages(userbot, limit=1)
                        xs = mssag17[0].click(0).message
                        io = (int(xs) - int(xe1))
                        sd(f'start 🐱‍👤 {cc} banded have {xe1}({io}) -- [{i}]')
                        client.disconnect()
                        break
                    else:
                        bn = bn + 1
            try:
                client.disconnect()
            except Exception:
                pass
        except Exception:
            pass


    def dele():
        delt = open('deleter.txt', 'r').read()
        def dle(cc):
            try:
                client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
                client.start()
                print(cc)
                dialogs = client.get_dialogs()
                for dialog in dialogs:
                    entity = dialog.entity
                    try:
                        #xu = entity.username
                        #xn = entity.title
                        ixx = entity.id
                    except:pass
                    if dialog.is_user:
                        pass
                    elif str(ixx) in str(delt):
                        pass
                    else:
                        #print(entity)
                        client.delete_dialog(entity)
                client.disconnect()
            except Exception:
                pass
        g = 1
        for ffguf in range(1000):
            F = ("dex" + str(g))
            dle(F)

            if int(g) == int(V):
                sd('cliened')
                sleep(555)
                break
            else:
                g = g + 1

    def sing():
        g = 41
        for dl in range(V):
            cc = ("dex" + str(g))
            try:
                client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
                client.start()
                sleep(0.5)
                sleep(1)
                print(cc)
                client.send_message(userbot, '/start')
                sleep(3)
                for x in range(22):
                    l1 = client.get_messages(userbot, limit=1)
                    l2=l1[0].message
                    if l2 == "/start":
                        client.send_message(userbot, '/start')
                        sleep(1)
                        continue
                    if l2 == "البوت تحت الصيانة حالياً 🛠️":
                        sleep(7000)
                        client.send_message(userbot, '/start')
                        sleep(1)
                        continue
                    if "@" in l2:
                        text = l2.find("@") + len("@")
                        fi = l2.find("\n", text)
                        nk = str(l2[text:fi])
                        client(JoinChannelRequest("https://t.me/" + nk))
                        client.send_message(userbot, '/start')
                        sleep(1)
                    else:
                        break
                sleep(1)
                mscsag33 = client.get_messages(userbot, limit=1)
                mscsag33[0].click(1)
                sleep(3)
                mscsag34 = client.get_messages(userbot, limit=1)
                mscsag34[0].click(0)
                sleep(3)
                i=0
                for ee in range(25):
                    try:
                        mscsag35 = client.get_messages(userbot, limit=1)
                        l2 = mscsag35[0].message
                        if 'لا يوجد قنوات حالياً 🤍' in l2:
                            #sd(cc+' '+str(i))
                            break
                        #text = l2.find("@") + len("@")
                        nk = str(l2[15:])
                        client(JoinChannelRequest(nk))
                        mscsag36 = client.get_messages(userbot, limit=1)
                        mscsag36[0].click(0)
                        sleep(3)
                        i+=1
                    except:
                        mscsag36 = client.get_messages(userbot, limit=1)
                        mscsag36[0].click(0)
                sleep(3)
                mscsag38 = client.get_messages(userbot, limit=1)
                mscsag38[0].click(0)
                sleep(3)
                mssag11 = client.get_messages(userbot, limit=1)
                x = mssag11[0].click(2)
                mscsag40 = client.get_messages(userbot, limit=1)
                m40 = mscsag40[0].message
                if '🗃️ الحساب' in m40:
                    sleep(3)
                    mscsag37 = client.get_messages(userbot, limit=1)
                    mscsag37[0].click(2)
                    sleep(3)
                    l14 = client.get_messages(userbot, limit=1)
                    l24 = l14[0].message
                    regex1 = r'[1234567890]\w+'
                    she = re.findall(regex1, l24)
                    sleep(3)
                    mscsag5 = client.get_messages(userbot, limit=1)
                    mscsag5[0].click(4)
                    sleep(1)
                    client.send_message(userbot, Dex)
                    sleep(1)
                    client.send_message(userbot, she[0])
                    bot2(cc, client , i)
                    client.disconnect()
                else:
                    bot2(cc, client , i)
                    client.disconnect()
            except Exception:
                print('jj')
                pass
            g = g + 1


    for ffguf in range(1):
        #dele()
        for eh in range(20):
            sing()
        sd('finsh coding testIIIIIIIIIIIIIIIII')


dex2()