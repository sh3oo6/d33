from telethon.errors import FloodError
from telethon.sync import *
from telethon.tl.functions.channels import JoinChannelRequest
import re
from telethon.tl.functions.messages import GetHistoryRequest
import requests
from time import *

Dex = '6140911166'
Des = '6329133667:AAHjUW5hqYxGv8BaL_YiFKoXSt4UCJZDi68'
V = 104

def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')

def d3():
    g = 1
    sleepdex = 4
    userbot = '@DamKombot'
    for dl in range(V):
        try:
            cc = ("dex" + str(g))
            client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
            client.connect()
            if not client.is_user_authorized():
                g = g + 1
                continue
            elif client.is_user_authorized():
                pass
            print(cc)
            client.send_message(userbot, '/start')
            sleep(1)
            for x in range(22):
                l1 = client.get_messages(userbot, limit=1)
                l2 = l1[0].message
                if l2 == "/start":
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if l2 == "البوت تحت الصيانة حالياً 🛠️":
                    sleep(3600)
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if "@" in l2:
                    text = l2.find("@") + len("@")
                    fi = l2.find("\n", text)
                    nk = str(l2[text:fi])
                    client(JoinChannelRequest("https://t.me/" + nk))
                    #except FloodError:
                    client.send_message(userbot, '/start')
                    sleep(1)
                else:
                    break
            try:
                sleep(sleepdex)
                dex1 = client.get_messages(userbot, limit=1)
                dex1[0].click(1)
                sleep(sleepdex)
                dex2 = client.get_messages(userbot, limit=1)
                dex2[0].click(0)
                sleep(1)
                idex = 0
                for ee in range(30):
                    try:
                        dex3 = client.get_messages(userbot, limit=1)
                        l7 = dex3[0].message
                        if 'لا يوجد قنوات حالياً 🤍' in l7:
                            sleep(sleepdex)
                            dex4 = client.get_messages(userbot, limit=1)
                            dex4[0].click(0)
                            sleep(sleepdex)
                            dex5 = client.get_messages(userbot, limit=1)
                            dex5[0].click(2)
                            sleep(1)
                            client.disconnect()
                            break
                        nk = str(l7[15:])
                        client(JoinChannelRequest(nk))
                        try:
                            dex3[0].click(0)
                        except:
                            sleep(sleepdex)
                            dex3[0].click(1)
                        idex = idex + 1
                        sleep(2)
                    except Exception:
                        try:
                            sd(cc + '  ' + str(idex))
                            client.disconnect()
                        except:
                            sd(cc + '  ' + str(idex))
                        break
            except:
                sd('DEX'+cc)
        except:pass
        g = g + 1
def sing():
    g = 1
    for dl in range(V):
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.connect()
        if not client.is_user_authorized():
            g = g + 1
            continue
        elif client.is_user_authorized():
            pass
        try:
            userbot = '@eeobot'
            client.send_message(userbot, '/start')
            sleep(3)
            chen = client.get_entity(userbot)
            dex1 = client.get_messages(userbot, limit=1)
            xe1 = dex1[0].click(0).message
            dex1[0].click(2)
            sleep(1)
            dex2 = client.get_messages(userbot, limit=1)
            dex2[0].click(0)
            bn = 1
            for chdex in range(100):
                lx = client(
                    GetHistoryRequest(peer=chen, limit=1, offset_date=None, offset_id=0, max_id=0,
                                      min_id=0,
                                      add_offset=0, hash=0))
                jx = lx.messages[0]
                vvf = jx.message
                if ('تم اضافة') in vvf or ('لا يوجد قنوات في الوقت الحالي') in vvf:
                    dex3 = client.get_messages(userbot, limit=1)
                    dex3[0].click(1)
                    sleep(1)
                    dex4 = client.get_messages(userbot, limit=1)
                    xs = dex4[0].click(0).message
                    io = (int(xs) - int(xe1))
                    sd(f'👾 start {cc} not have {xe1}({io})')
                    client.disconnect()
                    break
                elif ('• تم خصم 16 من نقاطك ⭕️') in vvf:
                    client.send_message(userbot, '/start')
                    sleep(1)
                    dex5 = client.get_messages(userbot, limit=1)
                    dex5[0].click(2)
                    dex6 = client.get_messages(userbot, limit=1)
                    dex6[0].click(0)
                    continue
                try:
                    url = jx.reply_markup.rows[0].buttons[0].url
                    if '+' in url or '-' in url :
                        dex7 = client.get_messages(userbot, limit=1)
                        dex7[0].click(1)
                        continue
                    client(JoinChannelRequest(url))
                    dex7 = client.get_messages(userbot, limit=1)
                    dex7[0].click(1)
                except FloodError:
                    print(FloodError)
                    dex9 = client.get_messages(userbot, limit=1)
                    dex9[0].click(4)
                    sleep(1)
                    dex10 = client.get_messages(userbot, limit=1)
                    xs = dex10[0].click(0).message
                    io = (int(xs) - int(xe1))
                    sd(f'start 🐱‍👤 {cc} banded have {xe1}({io})')
                    client.disconnect()
                    break
            try:
                client.disconnect()
            except Exception:
                pass
        except Exception:
            pass
        g = g + 1

for ffguf in range(1):
    for eh in range(5):
        try:
            start_time = time()
            sing()
            d3()
            end_time = time()
            execution_time = end_time - start_time
            sd(execution_time)
            sleep(86400-int(execution_time))
        except:
            sd('ERORR + _ +')