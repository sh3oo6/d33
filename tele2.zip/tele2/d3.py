from telethon.errors import FloodError
from telethon.sync import *
from telethon.tl.functions.channels import JoinChannelRequest
import re
from telethon.tl.functions.messages import GetHistoryRequest
import requests
from time import *

Dex = '6140911166'
Des = '6329133667:AAHjUW5hqYxGv8BaL_YiFKoXSt4UCJZDi68'
V = 92

def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')

def d3():
    g = 1
    userbot = '@DamKombot'
    for dl in range(V):
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.connect()
        print(cc)
        if not client.is_user_authorized():
            g = g + 1
            continue
        elif client.is_user_authorized():
            pass
        try:
            client.send_message(userbot, '/start')
            sleep(4)
            for x in range(22):
                l1 = client.get_messages(userbot, limit=1)
                l2 = l1[0].message
                if l2 == "/start":
                    client.send_message(userbot, '/start')
                    sleep(2)
                    continue
                if l2 == "البوت تحت الصيانة حالياً 🛠️":
                    sleep(3600)
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if "@" in l2:
                    text = l2.find("@") + len("@")
                    fi = l2.find("\n", text)
                    nk = str(l2[text:fi])
                    client(JoinChannelRequest("https://t.me/" + nk))
                    client.send_message(userbot, '/start')
                    sleep(2)
                else:
                    break

            sleep(4)
            dex1 = client.get_messages(userbot, limit=1)
            dex1[0].click(1)
            sleep(3)
            dex5 = client.get_messages(userbot, limit=1)
            dex5 = dex5[0].click(2).message
            if 'طالب' in dex5:
                print('jj')
                sleep(3)
                dex12 = client.get_messages(userbot, limit=1)
                dex12[0].click(3)
                sleep(3)
                dex6 = client.get_messages(userbot, limit=1)
                dex6[0].click(3)
                sleep(3)
                fi = open('gift.txt', 'r+')
                lines = fi.readlines()
                gifts = []
                for line in lines:
                    gifts.append(line.strip())
                fi.close()
                fe = open('gift.txt', 'w')
                for gift in gifts:
                    x = gift.replace('\n', '')
                    client.send_message(userbot , x)
                    sleep(3)
                    dex8 = client.get_messages(userbot, limit=2)
                    dex8e = dex8[1].message
                    if 'تم اضافة' in dex8e:
                        fe.write(gift + '\n')
                        sleep(5)
                        client.send_message(userbot, '/start')
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
                    elif 'الكود خطأ' in dex8[0].message:
                        client.send_message(userbot, '/start')
                        sleep(5)
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
            elif 'لقد حصلت' in dex5 :
                dex6 = client.get_messages(userbot, limit=1)
                dex6[0].click(3)
                sleep(3)
                fi = open('gift.txt', 'r+')
                lines = fi.readlines()
                gifts = []
                for line in lines:
                    gifts.append(line.strip())
                fi.close()
                fe = open('gift.txt', 'w')
                for gift in gifts:
                    x = gift.replace('\n', '')
                    client.send_message(userbot, x)
                    sleep(3)
                    dex8 = client.get_messages(userbot, limit=2)
                    dex8e = dex8[1].message
                    if 'تم اضافة' in dex8e:
                        fe.write(gift + '\n')
                        sleep(5)
                        client.send_message(userbot, '/start')
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
                    elif 'الكود خطأ' in dex8[0].message:
                        client.send_message(userbot, '/start')
                        sleep(5)
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
            client.disconnect()
            g = g + 1
        except:pass

def d32():
    g = 1
    userbot = '@DamKombot'
    for dl in range(V):
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.connect()
        if not client.is_user_authorized():
            g = g + 1
            continue
        elif client.is_user_authorized():
            pass
        try:
            client.send_message(userbot, '/start')
            sleep(3)
            for x in range(22):
                l1 = client.get_messages(userbot, limit=1)
                l2 = l1[0].message
                if l2 == "/start":
                    client.send_message(userbot, '/start')
                    sleep(2)
                    continue
                if l2 == "البوت تحت الصيانة حالياً 🛠️":
                    sleep(3600)
                    client.send_message(userbot, '/start')
                    sleep(1)
                    continue
                if "@" in l2:
                    text = l2.find("@") + len("@")
                    fi = l2.find("\n", text)
                    nk = str(l2[text:fi])
                    client(JoinChannelRequest("https://t.me/" + nk))
                    client.send_message(userbot, '/start')
                    sleep(2)
                else:
                    break

            sleep(4)
            dex1 = client.get_messages(userbot, limit=1)
            dex1[0].click(1)
            sleep(3)
            dex5 = client.get_messages(userbot, limit=1)
            dex5 = dex5[0].click(2).message
            if 'طالب' in dex5:
                sleep(3)
                dex12 = client.get_messages(userbot, limit=1)
                dex12[0].click(3)
                sleep(3)
                dex6 = client.get_messages(userbot, limit=1)
                dex6[0].click(3)
                sleep(3)
                fi = open('gift.txt', 'r+')
                lines = fi.readlines()
                gifts = []
                for line in lines:
                    gifts.append(line.strip())
                fi.close()
                fe = open('gift.txt', 'w')
                for gift in gifts:
                    x = gift.replace('\n', '')
                    client.send_message(userbot , x)
                    sleep(5)
                    dex8 = client.get_messages(userbot, limit=2)
                    dex8e = dex8[1].message
                    if 'تم اضافة' in dex8e:
                        fe.write(gift + '\n')
                        sleep(5)
                        client.send_message(userbot, '/start')
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
                    elif 'الكود خطأ' in dex8[0].message:
                        client.send_message(userbot, '/start')
                        sleep(5)
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
            elif 'لقد حصلت' in dex5 :
                sleep(3)
                dex61= client.get_messages(userbot, limit=1)
                dex61[0].click(2)
                sleep(3)
                dex6 = client.get_messages(userbot, limit=1)
                dex6[0].click(3)
                sleep(3)
                fi = open('gift.txt', 'r+')
                lines = fi.readlines()
                gifts = []
                for line in lines:
                    gifts.append(line.strip())
                fi.close()
                fe = open('gift.txt', 'w')
                for gift in gifts:
                    x = gift.replace('\n', '')
                    client.send_message(userbot, x)
                    sleep(3)
                    dex8 = client.get_messages(userbot, limit=2)
                    dex8e = dex8[1].message
                    if 'تم اضافة' in dex8e:
                        fe.write(gift + '\n')
                        sleep(5)
                        client.send_message(userbot, '/start')
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
                    elif 'الكود خطأ' in dex8[0].message:
                        client.send_message(userbot, '/start')
                        sleep(5)
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6[0].click(3)
            client.send_message(userbot, '/start')
            sleep(3)
            dex82 = client.get_messages(userbot, limit=1)
            dex82 = dex82[0].message
            regex1 = r'[1234567890]\w+'
            she = re.findall(regex1, dex82)
            sleep(3)
            dex92 = client.get_messages(userbot, limit=1)
            dex92[0].click(4)
            sleep(1)
            client.send_message(userbot, Dex)
            sleep(1)
            client.send_message(userbot, she[0])
            client.disconnect()
            g = g + 1
        except:pass

def sing():
    g = 1
    for dl in range(V):
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.connect()
        if not client.is_user_authorized():
            g = g + 1
            continue
        elif client.is_user_authorized():
            pass
        try:
            userbot = '@eeobot'
            client.send_message(userbot, '/start')
            sleep(3)
            chen = client.get_entity(userbot)
            dex1 = client.get_messages(userbot, limit=1)
            xe1 = dex1[0].click(0).message
            dex1[0].click(2)
            sleep(1)
            dex2 = client.get_messages(userbot, limit=1)
            dex2[0].click(0)
            bn = 1
            for chdex in range(100):
                lx = client(
                    GetHistoryRequest(peer=chen, limit=1, offset_date=None, offset_id=0, max_id=0,
                                      min_id=0,
                                      add_offset=0, hash=0))
                jx = lx.messages[0]
                vvf = jx.message
                if ('تم اضافة') in vvf or ('لا يوجد قنوات في الوقت الحالي') in vvf:
                    dex3 = client.get_messages(userbot, limit=1)
                    dex3[0].click(1)
                    sleep(1)
                    dex4 = client.get_messages(userbot, limit=1)
                    xs = dex4[0].click(0).message
                    io = (int(xs) - int(xe1))
                    sd(f'👾 start {cc} not have {xe1}({io})')
                    client.disconnect()
                    break
                elif ('• تم خصم 16 من نقاطك ⭕️') in vvf:
                    client.send_message(userbot, '/start')
                    sleep(3)
                    dex5 = client.get_messages(userbot, limit=1)
                    dex5[0].click(2)
                    dex6 = client.get_messages(userbot, limit=1)
                    dex6[0].click(0)
                    continue
                try:
                    url = jx.reply_markup.rows[0].buttons[0].url
                    client(JoinChannelRequest(url))
                    dex7 = client.get_messages(userbot, limit=1)
                    dex7[0].click(1)
                except Exception:
                    dex8 = client.get_messages(userbot, limit=1)
                    dex8[0].click(1)
                    if bn == 3:
                        dex9 = client.get_messages(userbot, limit=1)
                        dex9[0].click(4)
                        sleep(1)
                        dex10 = client.get_messages(userbot, limit=1)
                        xs = dex10[0].click(0).message
                        io = (int(xs) - int(xe1))
                        sd(f'start 🐱‍👤 {cc} banded have {xe1}({io})')
                        client.disconnect()
                        break
                    else:
                        bn = bn + 1
            try:
                client.disconnect()
            except Exception:
                pass
        except Exception:
            pass
        g = g + 1

for ffguf in range(1):
    for eh in range(5):
        start_time = time()
        sing()
        d3()
        end_time = time()
        execution_time = end_time - start_time
        sd(execution_time)
        sleep(86400-int(execution_time))