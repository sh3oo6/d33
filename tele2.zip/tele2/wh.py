from telethon.sync import *
from telethon.tl.functions.channels import JoinChannelRequest
import re
import requests
from time import *
from telethon.tl.functions.messages import GetHistoryRequest, ImportChatInviteRequest
import asyncio

#Dex = '5229914714'
#Des = '5938772476:AAHaSgf6WdTHQd1RqUifucJaaf11CQ0tkAg'
Dex = '6140911166'
#Des = '6312593326:AAHxQ-9-buwS6q70dCOvhKvkJaBWkzKZcZg'
Des = '6329133667:AAHjUW5hqYxGv8BaL_YiFKoXSt4UCJZDi68'
def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')
delt = open('deleter.txt', 'r').read()
userbot='@DamKombot'
def dex2():
    V=20
    def sing():
        g = 1
        for dl in range(V):
            cc = ("dex" + str(g))
            try:
                client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
                client.start()
                try:
                    dialogs = client.get_dialogs()
                    for dialog in dialogs:
                        entity = dialog.entity
                        try:
                            # xu = entity.username
                            # xn = entity.title
                            ixx = entity.id
                        except:
                            pass
                        if dialog.is_user:
                            pass
                        elif str(ixx) in str(delt):
                            pass
                        else:
                            client.delete_dialog(entity)
                    delt.close()
                except Exception:
                    pass
                print(cc)
                client.send_message(userbot, '/start')
                sleep(1)
                for x in range(22):
                    l1 = client.get_messages(userbot, limit=1)
                    l2=l1[0].message
                    if l2 == "/start":
                        client.send_message(userbot, '/start')
                        sleep(1)
                        continue
                    if l2 == "البوت تحت الصيانة حالياً 🛠️":
                        sleep(3600)
                        client.send_message(userbot, '/start')
                        sleep(1)
                        continue
                    if "@" in l2:
                        text = l2.find("@") + len("@")
                        fi = l2.find("\n", text)
                        nk = str(l2[text:fi])
                        client(JoinChannelRequest("https://t.me/" + nk))
                        client.send_message(userbot, '/start')
                        sleep(1)
                    else:
                        break
                sleep(4)
                mscsag33 = client.get_messages(userbot, limit=1)
                mscsag33[0].click(1)
                f = mscsag33[0].message
                sleep(3.1)
                mscsag34 = client.get_messages(userbot, limit=1)
                mscsag34[0].click(0)
                sleep(3)
                i = 0
                bn = 0
                for ee in range(30):
                    try:
                        mscsag35 = client.get_messages(userbot, limit=1)
                        l7 = mscsag35[0].message
                        if 'لا يوجد قنوات حالياً 🤍' in l7:
                            #sd(cc+' '+str(i))
                            sleep(3)
                            mscsag38 = client.get_messages(userbot, limit=1)
                            mscsag38[0].click(0)
                            sleep(3)
                            mssag11 = client.get_messages(userbot, limit=1)
                            x = mssag11[0].click(2)
                            mscsag40 = client.get_messages(userbot, limit=1)
                            m40 = mscsag40[0].message
                            if '🗃️ الحساب' in m40:
                                sleep(3)
                                mscsag37 = client.get_messages(userbot, limit=1)
                                mscsag37[0].click(2)
                                sleep(3)
                                l14 = client.get_messages(userbot, limit=1)
                                l24 = l14[0].message
                                regex1 = r'[1234567890]\w+'
                                she = re.findall(regex1, l24)
                                sleep(3)
                                mscsag5 = client.get_messages(userbot, limit=1)
                                mscsag5[0].click(4)
                                sleep(1)
                                client.send_message(userbot, Dex)
                                sleep(1)
                                client.send_message(userbot, she[0])
                                sd(cc +'  '+ str(i))
                                client.disconnect()
                            else:
                                sd(cc +'  '+ str(i))
                                client.disconnect()
                            break
                        #text = l2.find("@") + len("@")
                        nk = str(l7[15:])
                        client(JoinChannelRequest(nk))
                        #mscsag36 = client.get_messages(userbot, limit=1)
                        mscsag35[0].click(0)
                        i+=1
                        sleep(0.5)
                    except Exception:
                        bn += 1
                        sleep(3)
                        mscsag38 = client.get_messages(userbot, limit=1)
                        mscsag38[0].click(2)
                        sleep(3)
                        mssag11 = client.get_messages(userbot, limit=1)
                        x = mssag11[0].click(2)
                        mscsag40 = client.get_messages(userbot, limit=1)
                        m40 = mscsag40[0].message
                        if '🗃️ الحساب' in m40:
                            sleep(3)
                            mscsag37 = client.get_messages(userbot, limit=1)
                            mscsag37[0].click(2)
                            sleep(3)
                            l14 = client.get_messages(userbot, limit=1)
                            l24 = l14[0].message
                            regex1 = r'[1234567890]\w+'
                            she = re.findall(regex1, l24)
                            sleep(3)
                            mscsag5 = client.get_messages(userbot, limit=1)
                            mscsag5[0].click(4)
                            sleep(1)
                            client.send_message(userbot, Dex)
                            sleep(1)
                            client.send_message(userbot, she[0])
                            sd(cc +'  '+ str(i))
                            client.disconnect()
                        else:
                            sd(cc +'  '+ str(i))
                            client.disconnect()
                        break
            except Exception:
                print('jjj')
                sd(f)
                pass
            g = g + 1

    for ffguf in range(1):
        for eh in range(20):
            sing()
            sleep(1111)
        sd('finsh coding testIIIIIIIIIIIIIIIII')


dex2()