from telethon.sync import TelegramClient
import time
bot='@DamKombot'
client = TelegramClient('dex58', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
client.start()
client.send_message(bot,'/start')
time.sleep(2)
dex6 = client.get_messages(bot, limit=1)
dex6[0].click(0)
dex7 = client.get_messages(bot, limit=1)
x = dex7[0].click(0)
print(x)