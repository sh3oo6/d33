from telethon.sync import TelegramClient , events , Button, errors
import asyncio
def Add_NUMBER(api_id, api_hash, phone_number):
    phone_number = phone_number.replace('+', '').replace(' ', '')
    iqthon =TelegramClient(phone_number, api_id, api_hash)
    iqthon.connect()

    if not iqthon.is_user_authorized():
        iqthon.send_code_request(phone_number)


        response_verification_code = input('code?')
        verification_code = str(response_verification_code).replace('-', '')

        try:
            iqthon.sign_in(phone_number, code=int(verification_code))
        except errors.SessionPasswordNeededError:
            password = input('passpo')

            iqthon.sign_in(phone_number, password=password)

    return "تم اضافة الرقم بنجاح ✅"



Add_NUMBER(2192036 ,'3b86a67fc4e14bd9dcfc2f593e75c841' , '+37122293827' )