fi = open('gift.txt' , 'r+')
lines = fi.readlines()
gifts = []
for line in lines:
    gifts.append(line.strip())
fi.close()
fe = open('gift.txt' , 'w')
for gift in gifts:
    if not gift == 'gg8':
        fe.write(gift + '\n')

# no think is hard for me :)