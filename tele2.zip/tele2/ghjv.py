from telethon import TelegramClient, events

client = TelegramClient('dex58', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841').start()
@client.on(events.NewMessage)
async def my_event_handler(event):
    if 'hello' in event.raw_text:
        await event.reply('hi!')

client.start()
client.run_until_disconnected()
