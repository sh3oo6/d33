import telebot
token ='5965699318:AAHbRpWVpVZo2wZS1xcw1tsO9IfwydlHsIw'
bot = telebot.TeleBot(token)
import time
from telebot import types


# رسالة الترحيب
welcome_message = "مرحبًا بك في البوت!"

# إنشاء زر بدون إرسال نص
markup = types.InlineKeyboardMarkup()
button = types.InlineKeyboardButton("الضغط هنا", callback_data="button_pressed")
markup.add(button)

# التفاعل مع رسالة البداية
@bot.message_handler(commands=['start'])
def handle_start(message):
    bot.send_message(message.chat.id, f"{welcome_message}\n\n[إضغط هنا للضغط](callback_data='button_pressed')", parse_mode="Markdown", reply_markup=markup )

# استجابة عند الضغط على الزر
@bot.callback_query_handler(func=lambda call: call.data == "button_pressed")
def handle_button_click(call):
    pass


# تشغيل البوت
bot.polling()