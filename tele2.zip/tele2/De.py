from telethon.sync import TelegramClient
client = TelegramClient('dex581', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
client.connect()
if not client.is_user_authorized():
    print('no')
elif client.is_user_authorized():
    print('yes')