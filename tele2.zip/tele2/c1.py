
from telethon.errors import FloodError
from telethon.sync import *
from telethon.tl.functions.channels import JoinChannelRequest
import re
import requests
from time import *

Dex = '6140911166'
Des = '6312593326:AAHxQ-9-buwS6q70dCOvhKvkJaBWkzKZcZg'
userbot='@DamKombot'
V = 20

def sd(B):
    requests.post(f'https://api.telegram.org/bot{Des}/sendMessage?chat_id={Dex}&text={B}')


def sing():
    g = 1
    delt = open('deleter.txt', 'r').read()
    for dl in range(V):
        cc = ("dex" + str(g))
        client = TelegramClient(cc, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
        client.start()
        try:
            dialogs = client.get_dialogs()
            for dialog in dialogs:
                entity = dialog.entity
                try:
                    # xu = entity.username
                    # xn = entity.title
                    ixx = entity.id
                except:
                    pass
                if dialog.is_user:
                    pass
                elif str(ixx) in str(delt):
                    pass
                else:
                    client.delete_dialog(entity)
        except Exception:
            pass
        print(cc)
        client.send_message(userbot, '/start')
        sleep(1)
        for x in range(22):
            l1 = client.get_messages(userbot, limit=1)
            l2 = l1[0].message
            if l2 == "/start":
                client.send_message(userbot, '/start')
                sleep(1)
                continue
            if l2 == "البوت تحت الصيانة حالياً 🛠️":
                sleep(3600)
                client.send_message(userbot, '/start')
                sleep(1)
                continue
            if "@" in l2:
                text = l2.find("@") + len("@")
                fi = l2.find("\n", text)
                nk = str(l2[text:fi])
                try:
                    client(JoinChannelRequest("https://t.me/" + nk))
                except FloodError:
                    sd('flood')
                client.send_message(userbot, '/start')
                sleep(1)
            else:
                break
        try:
            sleep(4)
            dex1 = client.get_messages(userbot, limit=1)
            dex1[0].click(1)
            sleep(3)
            f = dex1[0].message
            dex2 = client.get_messages(userbot, limit=1)
            dex2[0].click(0)
            sleep(1)
            idex = 0
            for ee in range(30):
                try:
                    dex3 = client.get_messages(userbot, limit=1)
                    l7 = dex3[0].message
                    if 'لا يوجد قنوات حالياً 🤍' in l7:
                        sleep(3)
                        dex4 = client.get_messages(userbot, limit=1)
                        dex4[0].click(0)
                        sleep(3)
                        dex5 = client.get_messages(userbot, limit=1)
                        dex5[0].click(2)
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6 = dex6[0].message
                        if '🗃️ الحساب' in dex6:
                            sleep(3)
                            dex7 = client.get_messages(userbot, limit=1)
                            dex7[0].click(2)
                            sleep(1)
                            dex8 = client.get_messages(userbot, limit=1)
                            dex8 = dex8[0].message
                            regex1 = r'[1234567890]\w+'
                            she = re.findall(regex1, dex8)
                            sleep(3)
                            dex9 = client.get_messages(userbot, limit=1)
                            dex9[0].click(4)
                            sleep(1)
                            client.send_message(userbot, Dex)
                            sleep(1)
                            client.send_message(userbot, she[0])
                            sd(cc + '  ' + str(idex))
                            client.disconnect()
                        else:
                            sd(cc + '  ' + str(idex))
                            client.disconnect()
                        break
                    nk = str(l7[15:])
                    try:
                        client(JoinChannelRequest(nk))
                    except FloodError:
                        dex10 = client.get_messages(userbot, limit=1)
                        dex10[0].click(2)
                        sleep(3)
                        dex5 = client.get_messages(userbot, limit=1)
                        dex5[0].click(2)
                        dex6 = client.get_messages(userbot, limit=1)
                        dex6 = dex6[0].message
                        if '🗃️ الحساب' in dex6:
                            sleep(3)
                            dex7 = client.get_messages(userbot, limit=1)
                            dex7[0].click(2)
                            sleep(1)
                            dex8 = client.get_messages(userbot, limit=1)
                            dex8 = dex8[0].message
                            regex1 = r'[1234567890]\w+'
                            she = re.findall(regex1, dex8)
                            sleep(3)
                            dex9 = client.get_messages(userbot, limit=1)
                            dex9[0].click(4)
                            sleep(1)
                            client.send_message(userbot, Dex)
                            sleep(1)
                            client.send_message(userbot, she[0])
                            sd(cc + '  ' + str(idex))
                            client.disconnect()
                        else:
                            sd(cc + '  ' + str(idex))
                            client.disconnect()
                    try:
                        dex3[0].click(0)
                    except:
                        print('jjl')
                        sleep(3)
                        dex3[0].click(1)
                    idex = idex + 1
                    sleep(1)
                except Exception:
                    sleep(3)
                    dex10 = client.get_messages(userbot, limit=1)
                    dex10[0].click(2)
                    sleep(3)
                    dex5 = client.get_messages(userbot, limit=1)
                    dex5[0].click(2)
                    dex6 = client.get_messages(userbot, limit=1)
                    dex6 = dex6[0].message
                    if '🗃️ الحساب' in dex6:
                        sleep(3)
                        dex7 = client.get_messages(userbot, limit=1)
                        dex7[0].click(2)
                        sleep(1)
                        dex8 = client.get_messages(userbot, limit=1)
                        dex8 = dex8[0].message
                        regex1 = r'[1234567890]\w+'
                        she = re.findall(regex1, dex8)
                        sleep(3)
                        dex9 = client.get_messages(userbot, limit=1)
                        dex9[0].click(4)
                        sleep(1)
                        client.send_message(userbot, Dex)
                        sleep(1)
                        client.send_message(userbot, she[0])
                        sd(cc + '  ' + str(idex))
                        client.disconnect()
                    else:
                        sd(cc + '  ' + str(idex))
                        client.disconnect()
                    break
        except:
            sd('DEX#END '+cc)
        g = g + 1
for ffguf in range(1):
    for eh in range(20):
        sing()
        sleep(1111)
    sd('finsh coding testIIIIIIIIIIIIIIIII')