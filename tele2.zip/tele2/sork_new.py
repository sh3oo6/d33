from telethon.sync import TelegramClient , events
from telethon.tl.functions.channels import JoinChannelRequest
import re
import requests
from time import sleep
import asyncio

client = TelegramClient('sor', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
client.start()
p=client.get_messages('@dex_dexo',limit=1)
print(p[0].message)