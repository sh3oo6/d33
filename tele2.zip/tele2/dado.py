
dd = open('deleter.txt', 'r')
for l in dd :
    xxx= l.split()[0]
    print(xxx)